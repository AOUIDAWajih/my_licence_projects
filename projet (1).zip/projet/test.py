# import pygame
#
# pygame.init()
#
# # Set up the screen
# screen = pygame.display.set_mode((1000, 1000))
#
# # Load the images
# image1 = pygame.image.load("photos/cow.png")
# image2 = pygame.image.load("photos/dragon.png")
#
# # Set the grid cell size
# cell_width = 100
# cell_height = 100
#
# # Calculate the cell position
# cell_row = 2
# cell_column = 3
# cell_x = cell_column * cell_width
# cell_y = cell_row * cell_height
#
# # Draw the first image onto the screen
# screen.blit(image1, (cell_x, cell_y))
#
# # Draw the second image onto the screen with an offset
# offset_x = 20
# offset_y = 20
# screen.blit(image2, (cell_x + offset_x, cell_y + offset_y))
#
# # Update the screen
# pygame.display.flip()
#
# # Main game loop
# running = True
# while running:
#     for event in pygame.event.get():
#         if event.type == pygame.QUIT:
#             running = False
#
# # Quit the game
# pygame.quit()

import random
import time
from copy import copy, deepcopy

import pygame

from elements import Ground, Herb, Water, Lion, Dragon, Eagle, Mouse, Animal, Resource, Element
from planets import PlanetAlpha

# random.seed(1000)
# planet = PlanetAlpha(PLANET_LONGITUDE_CELLS_COUNT, PLANET_LATITUDE_CELLS_COUNT)
# planet.place_resources([Herb() for _ in range(HERBS_COUNT)])
# planet.place_resources([Water() for _ in range(WATERS_COUNT)])
# planet_resources_only = deepcopy(planet.grid)
# planet.place_animals([Lion() for _ in range(LIONS_COUNT)])
# planet.place_animals([Dragon() for _ in range(DRAGONS_COUNT)])
# planet.place_animals([Cow() for _ in range(COWS_COUNT)])
# planet.place_animals([Mouse() for _ in range(MOUSES_COUNT)])
#
# planet_with_animals_only = deepcopy(planet.grid)
# for i in range(PLANET_LATITUDE_CELLS_COUNT):
#     for j in range(PLANET_LONGITUDE_CELLS_COUNT):
#         if isinstance(planet.grid[i][j][0], Resource):
#             planet_with_animals_only[i][j][0] = Ground()
#
# print(planet_with_animals_only)

# for i in range(PLANET_LATITUDE_CELLS_COUNT):
#     for j in range(PLANET_LONGITUDE_CELLS_COUNT):
#         print(planet.grid[i][j].char_repr + "is instance of Animal : " + str(isinstance(planet.grid[i][j], Animal)))

lion = Lion()
mouse = Mouse()
herb = Herb()
print(isinstance(herb,Resource))