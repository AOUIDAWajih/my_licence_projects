import random
import time
from copy import deepcopy
import pygame
from elements import Ground, Herb, Water, Lion, Dragon, Eagle, Mouse, Animal, Resource
from planets import PlanetAlpha

class Game:
    def __init__(self):
        self.is_playing = False

    def launch_game(self, screen, WINDOW_HEIGHT, WINDOW_WIDTH, difficulty):
        random.seed(1000)
        planet = PlanetAlpha(difficulty.PLANET_LONGITUDE_CELLS_COUNT, difficulty.PLANET_LATITUDE_CELLS_COUNT,
                             difficulty)
        planet.place_resources([Herb() for _ in range(difficulty.HERBS_COUNT)])
        planet.place_resources([Water() for _ in range(difficulty.WATERS_COUNT)])
        planet_with_resources_only = deepcopy(planet.grid)
        planet.place_animals([Lion() for _ in range(difficulty.LIONS_COUNT)])
        planet.place_animals([Dragon() for _ in range(difficulty.DRAGONS_COUNT)])
        planet.place_animals([Eagle() for _ in range(difficulty.COWS_COUNT)])
        planet.place_animals([Mouse() for _ in range(difficulty.MOUSES_COUNT)])

        planet_with_animals_only = deepcopy(planet.grid)
        for i in range(difficulty.PLANET_LATITUDE_CELLS_COUNT):
            for j in range(difficulty.PLANET_LONGITUDE_CELLS_COUNT):
                if isinstance(planet.grid[i][j][0], Resource):
                    planet_with_animals_only[i][j][0] = Ground()

        ROWS = planet.lines_count
        COLUMNS = planet.columns_count

        CELL_WIDTH = WINDOW_WIDTH // COLUMNS
        CELL_HEIGHT = WINDOW_HEIGHT // ROWS

        running = True

        tour = 0
        while running:

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                    pygame.quit()

            if tour == 0:
                screen.fill((255, 255, 255))
                for i in range(ROWS):
                    for j in range(COLUMNS):
                        image = pygame.image.load("photos/" + planet.grid[i][j][0].__class__.__name__.lower() + ".png")
                        CELL_IMAGE = pygame.transform.scale(image, (CELL_WIDTH, CELL_HEIGHT))
                        x = j * CELL_WIDTH
                        y = i * CELL_HEIGHT
                        screen.blit(CELL_IMAGE, (x, y))
                pygame.display.update()
            tour += 1

            for i in range(ROWS):
                for j in range(COLUMNS):
                    animals_in_cell = deepcopy(planet_with_animals_only[i][j])

                    if len(planet_with_animals_only[i][j]) >= 2:
                        for animal in planet_with_animals_only[i][j]:
                            for k in range(len(animals_in_cell)):

                                if k < len(animals_in_cell) and animal.eats(animals_in_cell[k]):
                                    animals_in_cell.pop(k)

                    planet_with_animals_only[i][j] = animals_in_cell

                    for animal in planet_with_animals_only[i][j]:
                        if isinstance(animal, Animal):
                            cell_to_delete = (i, j)
                            cell_x = cell_to_delete[1] * CELL_WIDTH
                            cell_y = cell_to_delete[0] * CELL_HEIGHT
                            pygame.draw.rect(screen, (255, 255, 255), (cell_x, cell_y, CELL_WIDTH, CELL_HEIGHT))

                            if isinstance(planet_with_resources_only[i][j][0], Resource):
                                image = pygame.image.load(
                                    "photos/" + planet_with_resources_only[i][j][0].__class__.__name__.lower() + ".png")
                                cell_x = j * CELL_WIDTH
                                cell_y = i * CELL_HEIGHT
                                cell_image = pygame.transform.scale(image, (CELL_WIDTH, CELL_HEIGHT))
                                screen.blit(cell_image, (cell_x, cell_y))

                            image = pygame.image.load(
                                "photos/" + animal.__class__.__name__.lower() + ".png")
                            cell_x = j * CELL_WIDTH
                            cell_y = i * CELL_HEIGHT
                            cell_image = pygame.transform.scale(image, (CELL_WIDTH, CELL_HEIGHT))
                            screen.blit(cell_image, (cell_x, cell_y))

            time.sleep(2)
            pygame.display.update()

            planet_with_animals_only_copy = deepcopy(planet_with_animals_only)
            for i in range(ROWS):
                for j in range(COLUMNS):
                    nb_removed_animals = 0
                    for k in range(len(planet_with_animals_only[i][j])):
                        animal = planet_with_animals_only[i][j][k]
                        if isinstance(animal, Animal):
                            direction = random.choice(planet.WIND_ROSE)
                            if ((direction == planet.NORTH or direction == planet.NORTH_WEST or direction == planet.NORTH_EAST) and i == 0) \
                                    or ((direction == planet.SOUTH or direction == planet.SOUTH_WEST or direction == planet.SOUTH_EAST) and i == ROWS - 1) \
                                    or ((direction == planet.EAST or direction == planet.NORTH_EAST or direction == planet.SOUTH_EAST) and j == COLUMNS - 1) \
                                    or ((direction == planet.WEST or direction == planet.NORTH_WEST or direction == planet.NORTH_EAST) and j == 0):
                                direction = (0, 0)
                            if not direction == (0, 0):
                                new_row = i + direction[0]
                                new_column = j + direction[1]

                                if isinstance(planet_with_animals_only_copy[new_row][new_column][0], Animal):

                                    planet_with_animals_only_copy[new_row][new_column].append(animal)
                                else:
                                    planet_with_animals_only_copy[new_row][new_column][0] = animal

                                # Replace old cell of the animal with ground
                                planet_with_animals_only_copy[i][j].pop(k - nb_removed_animals)
                                nb_removed_animals += 1

                                if not planet_with_animals_only_copy[i][j]:
                                    cell_to_delete = (i, j)
                                    cell_x = cell_to_delete[1] * CELL_WIDTH
                                    cell_y = cell_to_delete[0] * CELL_HEIGHT
                                    pygame.draw.rect(screen, (255, 255, 255), (cell_x, cell_y, CELL_WIDTH, CELL_HEIGHT))
                                    planet_with_animals_only_copy[i][j].append(Ground())

                                if not isinstance(planet_with_resources_only[i][j][0], Resource):
                                    for animal_2 in planet_with_animals_only_copy[i][j]:
                                        image = pygame.image.load(
                                            "photos/" + animal_2.__class__.__name__.lower() + ".png")
                                        cell_image = pygame.transform.scale(image, (CELL_WIDTH, CELL_HEIGHT))
                                        cell_x = j * CELL_WIDTH
                                        cell_y = i * CELL_HEIGHT
                                        screen.blit(cell_image, (cell_x, cell_y))
                                else:
                                    image = pygame.image.load(
                                        "photos/" + planet_with_resources_only[i][j][
                                            0].__class__.__name__.lower() + ".png")
                                    cell_image = pygame.transform.scale(image, (CELL_WIDTH, CELL_HEIGHT))
                                    cell_x = j * CELL_WIDTH
                                    cell_y = i * CELL_HEIGHT
                                    screen.blit(cell_image, (cell_x, cell_y))

                                # Insert animal image in the new cell
                                if isinstance(planet_with_resources_only[new_row][new_column][0], Ground):
                                    cell_to_delete = (new_row, new_column)
                                    cell_x = cell_to_delete[1] * CELL_WIDTH
                                    cell_y = cell_to_delete[0] * CELL_HEIGHT
                                    pygame.draw.rect(screen, (255, 255, 255), (cell_x, cell_y, CELL_WIDTH, CELL_HEIGHT))

                                if len(planet_with_animals_only_copy[new_row][new_column]) >= 2:
                                    for animal_3 in planet_with_animals_only_copy[new_row][new_column]:
                                        image = pygame.image.load(
                                            "photos/" + animal_3.__class__.__name__.lower() + ".png")
                                        cell_x = new_column * CELL_WIDTH
                                        cell_y = new_row * CELL_HEIGHT
                                        cell_image = pygame.transform.scale(image, (CELL_WIDTH, CELL_HEIGHT))
                                        screen.blit(cell_image, (cell_x, cell_y))
                                else:
                                    image = pygame.image.load(
                                        "photos/" + animal.__class__.__name__.lower() + ".png")
                                    cell_x = new_column * CELL_WIDTH
                                    cell_y = new_row * CELL_HEIGHT
                                    cell_image = pygame.transform.scale(image, (CELL_WIDTH, CELL_HEIGHT))
                                    screen.blit(cell_image, (cell_x, cell_y))

            time.sleep(5)
            pygame.display.update()
            planet_with_animals_only = planet_with_animals_only_copy
