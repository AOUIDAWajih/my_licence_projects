import math

import pygame

from game import Game


class Difficulty:
    def __init__(self):
        self.is_launched = False
        self.difficulty = ""
        self.PLANET_CELL_PIXEL_SIZE = 50

    def update_difficulty(self, difficulty):
        self.difficulty = difficulty
        if difficulty == "hard":
            self.PLANET_LONGITUDE_CELLS_COUNT = 15
            self.PLANET_LATITUDE_CELLS_COUNT = 10
            self.COWS_COUNT = 5
            self.DRAGONS_COUNT = 1
            self.LIONS_COUNT = 3
            self.MOUSES_COUNT = 20
            self.WATERS_COUNT = 10
            self.HERBS_COUNT = 20
        if difficulty == "medium":
            self.PLANET_LONGITUDE_CELLS_COUNT = 12
            self.PLANET_LATITUDE_CELLS_COUNT = 8
            self.COWS_COUNT = 3
            self.DRAGONS_COUNT = 0
            self.LIONS_COUNT = 2
            self.MOUSES_COUNT = 12
            self.WATERS_COUNT = 6
            self.HERBS_COUNT = 12
        if self.difficulty == "easy":
            self.PLANET_LONGITUDE_CELLS_COUNT = 10
            self.PLANET_LATITUDE_CELLS_COUNT = 6
            self.COWS_COUNT = 2
            self.DRAGONS_COUNT = 0
            self.LIONS_COUNT = 1
            self.MOUSES_COUNT = 8
            self.WATERS_COUNT = 4
            self.HERBS_COUNT = 8

    def choose_diffculty(self):
        pygame.init()
        pygame.display.set_caption("Ecosystème")
        WINDOW_WIDTH = 1080
        WINDOW_HEIGHT = 712
        screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
        screen.fill((255, 255, 255))

        easy_button = pygame.image.load("photos/easy.png")
        easy_button_rect = easy_button.get_rect()
        easy_button_rect.x = math.ceil(WINDOW_WIDTH // 4 - easy_button.get_width() // 2)
        easy_button_rect.y = math.ceil(WINDOW_HEIGHT // 2 - easy_button.get_height() // 2)

        medium_button = pygame.image.load("photos/medium.png")
        medium_button_rect = medium_button.get_rect()
        medium_button_rect.x = math.ceil(2 * WINDOW_WIDTH // 4 - easy_button.get_width() // 2)
        medium_button_rect.y = math.ceil(WINDOW_HEIGHT // 2 - easy_button.get_height() // 2)

        hard_button = pygame.image.load("photos/hard.png")
        hard_button_rect = hard_button.get_rect()
        hard_button_rect.x = math.ceil(3 * WINDOW_WIDTH // 4 - easy_button.get_width() // 2)
        hard_button_rect.y = math.ceil(WINDOW_HEIGHT // 2 - easy_button.get_height() // 2)

        running = True

        game = Game()
        while running:
            if game.is_playing:
                game.launch_game(screen, WINDOW_HEIGHT, WINDOW_WIDTH, self)
            else:
                screen.blit(easy_button, easy_button_rect)
                screen.blit(medium_button, medium_button_rect)
                screen.blit(hard_button, hard_button_rect)
            pygame.display.flip()

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                    pygame.quit()

                elif event.type == pygame.MOUSEBUTTONDOWN:

                    if easy_button_rect.collidepoint(event.pos):
                        self.update_difficulty("easy")

                    elif medium_button_rect.collidepoint(event.pos):
                        self.update_difficulty("medium")

                    elif hard_button_rect.collidepoint(event.pos):
                        self.update_difficulty("hard")

                    game.is_playing = True
