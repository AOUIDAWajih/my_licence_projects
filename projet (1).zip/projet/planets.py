import random

from elements import Ground, Element, Animal, Resource
from grid import Grid
# from config import PLANET_LONGITUDE_CELLS_COUNT, PLANET_LATITUDE_CELLS_COUNT


class PlanetAlpha(Grid):
    NORTH = (-1, 0)
    EAST = (0, 1)
    SOUTH = (1, 0)
    WEST = (0, 1)
    NORTH_EAST = (-1, 1)
    SOUTH_EAST = (1, 1)
    SOUTH_WEST = (1, -1)
    NORTH_WEST = (-1, -1)
    CARDINAL_POINTS = (NORTH, EAST, SOUTH, WEST)
    WIND_ROSE = (NORTH, NORTH_EAST, EAST, SOUTH_EAST, SOUTH, SOUTH_WEST, WEST, NORTH_WEST)

    current_animals_count = 0

    def __init__(self, longitude_cells_count, latitude_cells_count, difficulty):
        super().__init__(
            [[[Ground()] for j in range(difficulty.PLANET_LONGITUDE_CELLS_COUNT)] for i in
             range(difficulty.PLANET_LATITUDE_CELLS_COUNT)])
        self.longitude_cells_count = longitude_cells_count
        self.latitude_cells_count = latitude_cells_count

    def get_current_animals(self):
        return self.current_animals_count

    def incr_current_animals_count(self):
        self.current_animals_count += 1

    def decr_current_animals_count(self):
        self.current_animals_count -= 1

    # def get_ground(self):
    #     return self.ground

    def is_free_place(self, line_number, column_number):
        return not (isinstance(self.grid[line_number][column_number][0], Animal)
                    or isinstance(self.grid[line_number][column_number][0], Resource))

    def get_random_free_place(self):
        line_number = random.randint(0, self.lines_count - 1)
        column_number = random.randint(0, self.columns_count - 1)
        while not self.is_free_place(line_number, column_number):
            line_number = random.randint(0, self.lines_count - 1)
            column_number = random.randint(0, self.columns_count - 1)
        return line_number, column_number

    def place_resources(self, resources):
        for resource in resources:
            line_number, column_number = self.get_random_free_place()
            self.grid[line_number][column_number][0] = resource

    def place_animals(self, animals):
        for animal in animals:
            line_number, column_number = self.get_random_free_place()
            self.grid[line_number][column_number][0] = animal
            self.incr_current_animals_count()

    def get_grid_char_repr(self):
        planet_str = ""
        for i in range(self.latitude_cells_count):
            str = ""
            for j in range(self.longitude_cells_count):
                str += (self.grid[i][j]).char_repr
            planet_str += str + "\n"
        return planet_str

    def get_count(self, value):
        count = 0
        for i in range(self.latitude_cells_count):
            for j in range(self.longitude_cells_count):
                if type(self.grid[i][j]) == type(value):
                    count += 1
        return count

    def has_equal_value_cell_numbers(self, value):
        return True

    def get_same_value_cell_numbers(self, value):
        list = []
        for i in range(self.latitude_cells_count):
            for j in range(self.longitude_cells_count):
                if type(self.grid[i][j]) == type(value):
                    list.append(self.get_cell_number_from_coordinates(i,j))
        return list


    def get_lines_count(self):
        return self.lines_count

    def get_column_count(self):
        return self.columns_count
