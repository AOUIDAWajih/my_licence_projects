import math

import pygame

from config import Difficulty

if __name__ == '__main__':
    pygame.init()
    pygame.display.set_caption("Ecosystème")
    WINDOW_WIDTH = 1080
    WINDOW_HEIGHT = 712
    screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
    screen.fill((255, 255, 255))

    background = pygame.image.load("photos/ecosystem_2.jpeg")
    background_resized = pygame.transform.scale(background, (WINDOW_WIDTH, WINDOW_HEIGHT))
    # background =
    play_button = pygame.image.load("photos/play.png")
    quit_button = pygame.image.load("photos/quit.png")

    play_button_resized = pygame.transform.scale(play_button, (100, 100))
    play_button_rect = play_button_resized.get_rect()
    play_button_rect.x = math.ceil(WINDOW_WIDTH // 3 - play_button_resized.get_width() // 2)
    play_button_rect.y = math.ceil(WINDOW_HEIGHT // 2 - play_button_resized.get_height() // 2 + 275)

    quit_button_resized = pygame.transform.scale(quit_button, (100, 100))
    quit_button_rect = quit_button_resized.get_rect()
    quit_button_rect.x = math.ceil(2 * WINDOW_WIDTH // 3 - play_button_resized.get_width() // 2)
    quit_button_rect.y = math.ceil(WINDOW_HEIGHT // 2 - play_button_resized.get_height() // 2 + 275)

    running = True

    background_place = (WINDOW_WIDTH // 2 - background_resized.get_width() // 2,
                        WINDOW_HEIGHT // 2 - background_resized.get_height() // 2)
    # play_button_place = (WINDOW_WIDTH // 2 - play_button_resized.get_width() // 2,
    #                      WINDOW_HEIGHT // 2 - play_button_resized.get_height() // 2 + 250)

    # game = Game()
    difficulty = Difficulty()
    while running:
        screen.blit(background_resized, background_place)

        if difficulty.is_launched:
            difficulty.choose_diffculty()
        else:
            screen.blit(play_button_resized, play_button_rect)
            screen.blit(quit_button_resized, quit_button_rect)
        pygame.display.flip()

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()

            elif event.type == pygame.MOUSEBUTTONDOWN:

                if play_button_rect.collidepoint(event.pos):
                    difficulty.is_launched = True

                elif quit_button_rect.collidepoint(event.pos):
                    pygame.quit()
