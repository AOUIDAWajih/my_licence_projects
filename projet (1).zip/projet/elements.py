import random

i = 1


class Element:
    ids_count = 0

    def __init__(self, name, char_repr):
        self.name = name
        self.char_repr = char_repr
        self.incr_ids_count(Element)
        self.id = self.ids_count

    def get_ids_count(self):
        return self.ids_count

    @staticmethod
    def incr_ids_count(self):
        self.ids_count += 1

    def get_name(self):
        return self.name

    def get_id(self):
        return self.id

    def get_char_repr(self):
        return self.char_repr

    def __repr__(self):
        return self.char_repr + " : " + self.name + " " + str(self.id)


class Animal(Element):
    def __init__(self, name, char_repr, life_max):
        global a
        super().__init__(name, char_repr)
        self.life_max = life_max
        self.age = 0
        self.gender = random.randint(0, 1)
        self.bar_life = [life_max, life_max]

        line_direction = random.randint(-1, 1)
        column_direction = random.randint(-1, 1)
        while line_direction == column_direction == 0:
            column_direction = random.randint(-1, 1)
        self.current_direction = [line_direction, column_direction]
        self.direction = "none"

    def get_age(self):
        return self.age

    def ageing(self):
        self.age += 1

    def get_gender(self):
        return self.gender

    def get_life_max(self):
        return self.life_max

    def get_life(self):
        return self.bar_life[0]

    def is_alive(self):
        return self.get_life() > 0

    def is_dead(self):
        return self.get_life() <= 0

    def recovering_life(self, value):
        self.bar_life[0] += value

    def losing_life(self, value):
        self.bar_life[0] -= value

    def get_current_direction(self):
        return self.current_direction

    def set_current_direction(self, line_direction, column_direction):
        self.current_direction[0] = line_direction
        self.current_direction[1] = column_direction

    def __repr__(self):
        ch = self.char_repr + " : " + self.name + " " + str(self.id) + " ("
        if self.get_gender() == 0:
            ch += "femelle "
        else:
            ch += "male "
        ch += " de " + str(self.get_age()) + " an(s)) - Barre de vie : " + str(self.get_life()) + "/" + str(
            self.get_life_max())
        return ch

    def eats(self, animal):
        return False


class Mouse(Animal):
    def __init__(self):
        super().__init__("Mouse", "\U0001F42D", 2)

    def eats(self, animal):
        return False


class Lion(Animal):
    def __init__(self):
        super().__init__("Lion", "\U0001F981", 10)

    def eats(self, animal):
        if isinstance(animal, Eagle) or isinstance(animal, Mouse):
            return True
        return False


class Dragon(Animal):
    def __init__(self):
        super().__init__("Dragon", "\U0001F432", 20)

    def eats(self, animal):
        if isinstance(animal, Eagle) or isinstance(animal, Mouse) or isinstance(animal, Lion):
            return True
        return False


class Eagle(Animal):
    def __init__(self):
        super().__init__("Cow", "\U0001F42E", 5)

    def eats(self, animal):
        if isinstance(animal, Mouse):
            return True
        return False


class Resource(Element):
    def __init__(self, name, char_repr, value):
        super().__init__(name, char_repr)
        self.value = value

    def get_value(self):
        return self.value


class Herb(Resource):
    def __init__(self):
        super().__init__("Herb", "\U0001F33F", 1)


class Water(Resource):
    def __init__(self):
        super().__init__("Water", "\U0001F41F", 2)


class Ground(Element):
    def __init__(self):
        super().__init__("Ground", '.')
